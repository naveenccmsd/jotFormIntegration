package net.javaguides.springboot.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import net.javaguides.springboot.model.Employee;

@RestController
//@RequestMapping("/api/v1/")
public class EmployeeController {

	Logger logger = LoggerFactory.getLogger(EmployeeController.class);

	@PostMapping("/employees1")
	public Employee createEmployee(@RequestBody Employee employee) {
		logger.info("Result : {}" , employee);
		return employee;
	}

	@CrossOrigin(origins = {"http://localhost:8081", "http://localhost:8080","http://localhost:80"})
	@PostMapping("/employees")
	public Object test(@RequestBody Object employee) {
		logger.info("Result : {}" , JsonUtil.objectToJson(employee));
		return employee;
	}

	@PostMapping("/employees/undefined")
	public Object test1(@RequestBody Object employee) {
		logger.info("Result : {}" , JsonUtil.objectToJson(employee));
		return employee;
	}

	@PutMapping("/employees/1234")
	public Object ddfsd(@RequestBody Object employee) {
		logger.info("Result : {}" , JsonUtil.objectToJson(employee));
		return employee;
	}

}
