package net.javaguides.springboot.repository;


public interface EmployeeRepository{

}
